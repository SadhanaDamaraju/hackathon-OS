from process_simulation import ProcessManager

def main():
    manager = ProcessManager()


    manager.create_process("P1")
    manager.create_process("P2")
    manager.create_process("P3")


    manager.request_resource("P1", "P2")
    manager.request_resource("P2", "P3")
    manager.request_resource("P3", "P1")  

    print("\n--- Detecting Deadlock ---")
    if manager.detect_deadlock():
        print("🔥 Deadlock detected!")
        manager.recover_from_deadlock()
    else:
        print("✅ No deadlock detected.")

    manager.print_graph()


    print("\n--- Second Run (AI Prediction Test) ---")
    manager.create_process("P1")
    manager.create_process("P2")
    manager.create_process("P3")

    manager.request_resource("P1", "P2")
    manager.request_resource("P2", "P3")
    manager.request_resource("P3", "P1")

    manager.print_graph()

if __name__ == "__main__":
    main()
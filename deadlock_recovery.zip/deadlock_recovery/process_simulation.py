import os

class ProcessManager:
    def __init__(self):
        self.graph = {}
        self.history_file = "history.log"
        self.safe_mode = True

    def create_process(self, pid):
        if pid not in self.graph:
            self.graph[pid] = []
            print(f"✅ Created process {pid}")

    def request_resource(self, from_pid, to_pid):
        if from_pid in self.graph and to_pid in self.graph:
            temp_graph = {p: list(waits) for p, waits in self.graph.items()}
            temp_graph[from_pid].append(to_pid)


            risk_score = len(self.normalize_cycles(temp_graph)) * 10
            print(f"🧠 Risk score for this request: {risk_score}/100")


            if self.check_historical_pattern(temp_graph):
                print(f"⚠️ Request from {from_pid} to {to_pid} BLOCKED (AI predicted deadlock).")
                self.log_request(from_pid, to_pid, risk_score, "BLOCKED")
                return


            if self.safe_mode and risk_score > 20:
                print(f"❌ Safe Mode: Request blocked due to high risk.")
                self.log_request(from_pid, to_pid, risk_score, "BLOCKED")
                return

            self.graph[from_pid].append(to_pid)
            print(f"🔗 {from_pid} is now waiting for {to_pid}")
            self.log_request(from_pid, to_pid, risk_score, "ALLOWED")

    def print_graph(self):
        print("📊 Current Wait-For Graph:")
        for proc, waits in self.graph.items():
            print(f"  {proc} -> {', '.join(waits) if waits else 'None'}")

    def detect_deadlock(self):
        visited = set()
        rec_stack = set()

        def dfs(pid):
            visited.add(pid)
            rec_stack.add(pid)
            for neighbor in self.graph.get(pid, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            rec_stack.remove(pid)
            return False

        for node in self.graph:
            if node not in visited:
                if dfs(node):
                    return True
        return False

    def recover_from_deadlock(self):
        if not self.graph:
            print("ℹ️ No processes to terminate.")
            return

        victim = list(self.graph.keys())[0]
        print(f"💥 Terminating process {victim} to resolve deadlock.")


        cycles = self.normalize_cycles(self.graph)
        with open(self.history_file, "a") as f:
            for cycle in cycles:
                f.write(",".join(cycle) + "\n")


        del self.graph[victim]
        for waits in self.graph.values():
            if victim in waits:
                waits.remove(victim)

    def normalize_cycles(self, graph):
        # Detect all unique cycles as sorted tuples
        cycles = set()
        for start in graph:
            stack = [(start, [start])]
            while stack:
                (node, path) = stack.pop()
                for neighbor in graph.get(node, []):
                    if neighbor == path[0] and len(path) > 2:
                        cycles.add(tuple(sorted(path)))
                    elif neighbor not in path:
                        stack.append((neighbor, path + [neighbor]))
        return sorted(cycles)

    def check_historical_pattern(self, graph):
        norm_patterns = self.normalize_cycles(graph)
        if not os.path.exists(self.history_file):
            return False
        with open(self.history_file, "r") as f:
            existing = {line.strip() for line in f}
        for pat in norm_patterns:
            if ",".join(pat) in existing:
                return True
        return False

    def log_request(self, from_pid, to_pid, risk_score, status):
        with open("requests.log", "a") as log:
            log.write(f"{from_pid}->{to_pid} | Risk={risk_score} | {status}\n")
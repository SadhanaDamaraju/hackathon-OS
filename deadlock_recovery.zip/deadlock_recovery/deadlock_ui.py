import curses
from process_simulation import ProcessManager

def main(stdscr):
    curses.curs_set(0)
    manager = ProcessManager()

    menu = [
        "1. Create Process",
        "2. Request Resource",
        "3. Show Graph",
        "4. Detect Deadlock",
        "5. Recover from Deadlock",
        "6. View History Log",
        "7. View Request Log",
        "8. Exit"
    ]

    def draw_menu(selected):
        stdscr.clear()
        stdscr.addstr(0, 2, "🧠 Deadlock Prevention System", curses.A_BOLD)
        for idx, item in enumerate(menu):
            if idx == selected:
                stdscr.attron(curses.color_pair(1))
                stdscr.addstr(idx + 2, 4, item)
                stdscr.attroff(curses.color_pair(1))
            else:
                stdscr.addstr(idx + 2, 4, item)
        stdscr.refresh()

    def get_input(prompt):
        stdscr.clear()
        stdscr.addstr(0, 0, prompt)
        stdscr.refresh()
        curses.echo()
        input_str = stdscr.getstr(1, 0, 20).decode()
        curses.noecho()
        return input_str

    curses.start_color()
    curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)

    current_row = 0

    while True:
        draw_menu(current_row)
        key = stdscr.getch()

        if key == curses.KEY_UP and current_row > 0:
            current_row -= 1
        elif key == curses.KEY_DOWN and current_row < len(menu) - 1:
            current_row += 1
        elif key == curses.KEY_ENTER or key in [10, 13]:
            stdscr.clear()
            if current_row == 0:
                pid = get_input("Enter process ID:")
                manager.create_process(pid)
            elif current_row == 1:
                from_pid = get_input("From Process:")
                to_pid = get_input("To Process:")
                manager.request_resource(from_pid, to_pid)
            elif current_row == 2:
                stdscr.addstr(0, 0, "Current Graph:\n")
                y = 1
                for proc, waits in manager.graph.items():
                    stdscr.addstr(y, 2, f"{proc} -> {', '.join(waits) if waits else 'None'}")
                    y += 1
            elif current_row == 3:
                if manager.detect_deadlock():
                    stdscr.addstr(0, 0, "🔥 Deadlock Detected!")
                else:
                    stdscr.addstr(0, 0, "✅ No Deadlock.")
            elif current_row == 4:
                manager.recover_from_deadlock()
                stdscr.addstr(0, 0, "💥 Deadlock Recovered.")
            elif current_row == 5:
                stdscr.addstr(0, 0, "History Log:\n")
                if not manager.history_file or not open(manager.history_file).read().strip():
                    stdscr.addstr(1, 2, "(empty)")
                else:
                    with open(manager.history_file, "r") as f:
                        for i, line in enumerate(f.readlines()):
                            stdscr.addstr(i + 1, 2, line.strip())
            elif current_row == 6:
                stdscr.addstr(0, 0, "Request Log:\n")
                try:
                    with open("requests.log", "r") as f:
                        for i, line in enumerate(f.readlines()):
                            stdscr.addstr(i + 1, 2, line.strip())
                except FileNotFoundError:
                    stdscr.addstr(1, 2, "(log file not found)")
            elif current_row == 7:
                break

            stdscr.addstr(curses.LINES - 1, 0, "Press any key to return to menu...")
            stdscr.getch()

curses.wrapper(main)